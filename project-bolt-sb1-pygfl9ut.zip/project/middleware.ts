import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function middleware(req: NextRequest) {
  // Get session from cookie
  const sessionToken = req.cookies.get('session')?.value;
  const hasSession = !!sessionToken;

  // Protect app routes
  if (req.nextUrl.pathname.startsWith('/app')) {
    if (!hasSession) {
      return NextResponse.redirect(new URL('/auth/sign-in', req.url));
    }
  }

  // Redirect authenticated users away from auth pages
  if (req.nextUrl.pathname.startsWith('/auth') && hasSession) {
    return NextResponse.redirect(new URL('/app', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/app/:path*', '/auth/:path*']
};